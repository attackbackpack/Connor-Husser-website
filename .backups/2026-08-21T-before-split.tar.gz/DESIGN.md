# DESIGN.md — Connor Husser

Design system of record for `index.html`. The approved visual reference is
`.impeccable/mocks/transformation-field.webp`; the approved brief is
`.impeccable/surfaces/index-html.md`. Where this file and a future edit
disagree, this file wins until it is deliberately revised.

---

## 1. Brand thesis

Three real business truths — Clarity, Proof, and Contact — converge into one
online presence the owner controls.

This is Connor Husser's personal practice, not an agency. One person reviews
the business, designs and builds the site, launches it, and hands ownership
back. Personal accountability is the strongest proof on offer, so the page is
built to make one person legible rather than to imply a team.

**World name:** Seeded Identity. A deterministic seed (`eb2fb559`) drives the
line field, the palette, the divider rules, the control glyphs, and the
motion, so the identity is one system rather than a set of decorations.

**What the page refuses**

- A generic agency hero followed by a pricing stack.
- Cards as the page structure. There are no cards on this page.
- Shadows, glass, bento grids, stock photography, device mockups.
- Eyebrows or kickers above headings.
- Section numbering (01 / 02 / 03).
- Gradient text. Gradients appear only in the field and the primary action.
- Any claim the evidence does not support.

---

## 2. Visual system

### Palette

**24 tokens, zero unused, zero colour literals anywhere outside `:root`** —
not in the stylesheet, not in markup attributes, not in the canvas code.

| Token | Value | Role |
| --- | --- | --- |
| `--ground` | `#FBFAF9` | Luminous off-white page surface |
| `--night` | `#0D1020` | Deep ink; the closing section and the footer |
| `--ink` | `#0D1020` | Headings, labels, primary text on light |
| `--ink-body` | `#3A3B4C` | Body prose on light (10.6:1 on ground) |
| `--ink-mute` | `#65667A` | Meta and hints on light (5.4:1 on ground) |
| `--rule` | `#E3E1E6` | Hairline rules between sections and rows (decorative) |
| `--edge` | `#8F8E9B` | Boundaries of **interactive controls** (3.09:1 on ground) |
| `--violet` | `#6B41FC` | Clarity seed role |
| `--azure` | `#4A7CFF` | Proof seed role |
| `--sea` | `#22BFC6` | Mid-field seed role |
| `--lime` | `#88D85C` | Late-field seed role |
| `--solar` | `#FFD84D` | Far-field seed role |
| `--mint-ink` | `#2E9E63` | Contact role where it must carry meaning (3.26:1) |
| `--ink-inverse` | `#F5F4F9` | Headings and links on the dark surface |
| `--ink-inverse-body` | `#C9C9D6` | Prose on the dark surface (11.5:1) |
| `--ink-inverse-mute` | `#9C9DB0` | Meta on the dark surface (7.1:1) |
| `--ink-inverse-faint` | `#83849A` | Footer on the dark surface (5.2:1) |
| `--rule-inverse` | `#1D2038` | Hairline on the dark surface |
| `--select-bg` | `#DED2FF` | Text selection |
| `--surface-hover` | `#F1EFF4` | Hover fill on outlined controls |

Violet, azure, mint, and yellow are **seed roles**, not decorative accents.
Each hue belongs to one input and to one position along the field.

**The five seed tokens are the only definition of the palette.** The CTA
gradient composes them with `var()`; the canvas ramp reads them back with
`getComputedStyle` at startup; the wordmark's gradient stops take them through
`stop-color`; and every status glyph inherits them through a role class rather
than carrying a `fill` attribute. Changing `--violet` in `:root` moves the
Clarity glyph, its slider track, the gradient's first stop, the wordmark, and
the canvas field together — verified by overriding the token at runtime.

**Roles are applied by name, never by value.** `.seed-clarity`,
`.seed-proof`, and `.seed-contact` each set the local `--accent`, and anything
belonging to an input wears its role: the control row, the process step, the
glyph. There are no inline `style="--accent:…"` declarations and no hex values
in markup.

`--mint-ink` exists because the Contact role has two jobs. In the field it is
decorative and uses the lighter `--lime`; on a glyph it carries meaning and
must clear 3:1, so it darkens. That split is deliberate — do not merge them.

**Ground is deliberately near-neutral** (`R251 G250 B249`). It is not cream,
not beige, and not blue-white. It reads as paper under daylight.

### Gradient

```
--seed-gradient: linear-gradient(96deg,
  #6B41FC 0%, #4A7CFF 34%, #22BFC6 63%, #FFD84D 100%);
```

The gradient exists in exactly two places: inside the transformation field,
and inside the primary action. Nowhere else.

**Primary action contrast.** The action carries `--night` text on the full
gradient at `700 / 19px / uppercase`, which is WCAG large-scale text (3:1).
Measured against every stop: violet 3.38:1, azure 5.07:1, sea 8.2:1,
solar 12.4:1. White text was rejected: it fails against the mint and solar
stops, and truncating the ramp to keep white legible would have cost the
brand its two warm seed roles.

**Decorative rules and control boundaries are different roles.** A line that
merely separates content stays a hairline at `--rule`; a line that tells you
where a control is or how far it goes uses `--edge` and clears 3:1, because
WCAG 1.4.11 applies to the second and not the first. Do not collapse them back
into one token.

### Surface grammar

- Flat vector surfaces. No shadow, no blur, no glass, anywhere.
- One-pixel rules separate sections and rows. Elevation is never doubled.
- Corners stay square. Pills are reserved for the two compact actions and the
  three range controls. The living field supplies all curvature.
- Browser surfaces are themed: text selection uses `#DED2FF` on `--ink`, and
  focus rings are authored rather than inherited.

---

## 3. Typography

Self-hosted from `assets/fonts/`. No network fetch, no system fallback as the
display voice.

| Face | Weights shipped | Used for |
| --- | --- | --- |
| Barlow | 400, 500, 600 | Headline, body, labels, wordmark, actions |
| Barlow Condensed | 500, 600 | Service titles, section headings, process steps |

| Role | Size | Weight | Tracking |
| --- | --- | --- | --- |
| `h1` | `clamp(2.625rem, 5vw, 4.5rem)` → 42px phone, 72px desktop | 500 | −0.028em |
| Service title (`h3`) | `clamp(1.75rem, 3.4vw, 2.5rem)` uppercase | Condensed 600 | +0.012em |
| Section heading (`h2`) | `clamp(1.75rem, 3.1vw, 2.375rem)` uppercase | Condensed 600 | +0.012em |
| Closing heading | `clamp(2rem, 4.2vw, 3.25rem)` sentence case | Barlow 500 | −0.024em |
| Work item title (`h3`) | `clamp(1.375rem, 2.1vw, 1.75rem)` | 500 | −0.012em |
| Process step (`h3`) | `clamp(1.375rem, 2vw, 1.625rem)` uppercase | Condensed 500 | +0.03em |
| Body | 1.0625rem / 1.62 | 400 | 0 |
| Micro label | 0.8125rem (13px) uppercase | 600 | +0.15–0.17em |

**Rules.** Tracking never goes below −0.04em. Wide tracking is used only on
short uppercase labels, never on prose. Nothing on the page is smaller than
13px. Every heading level is present and none is skipped.

**Measure.** Body columns are capped between 40ch and 66ch:
hero note 44ch, service copy 56ch, work description 60ch, process step 52ch,
closing prose 56ch, control hint 40ch, closing note 66ch. Nothing wraps past
80 characters at any breakpoint.

---

## 4. Spacing and layout

- Page gutter: `clamp(18px, 4.4vw, 64px)`. Content maxes at 1560px.
- Section rhythm is deliberately uneven, not a single repeated value:
  hero `clamp(40px,5vw,72px)` top, service rows `clamp(28px,3.6vw,44px)`,
  work and process sections `clamp(52px,7vw,96px)`, dark close
  `clamp(64px,8vw,120px)`.
- Tight inside a group (10–14px), generous between groups. Headings always
  carry more space above than below.
- Desktop hero is a three-part topology: controls left (25%), open field
  centre, outcome right (40%), with the canvas layered beneath at `inset:0`.
- Service rows are full-width editorial bands: glyph, title behind a 1px
  vertical rule, prose column. Not cards, never boxed.
- The work index is a two-column record on desktop (status left, content
  right) and a single stacked column on phones.

---

## 5. Transformation field

One generator (`drawField`) drives three surfaces: the hero field, a quiet
band behind the service rows, and a quiet band inside the dark close.

**Determinism.** The seed string `eb2fb559` is hashed (FNV-1a) into a
`mulberry32` PRNG. The seed fixes *system constants only* — flow frequencies,
phase ladders, and colour drift. Everything that varies per path varies
**smoothly across the bundle**, which is what produces interference bands
instead of noise. The same seed produces the same drawing on every load and
every device.

**Structure.** 120 paths — 40 per input — integrated forward through a curl
field:

1. **Approach** (first 22% of the path). Each input reads as one legible line
   leaving its own control, bowing open and closing back on a shared waist.
   The bundle is drawn at 30% weight here so it reads as a line, not a mass.
2. **Waist.** The three inputs pinch together.
3. **Opening.** The fan opens quickly, then arcs over rather than running as
   straight rays. A three-term curl field warps the bundle, and the angle is
   soft-clamped with `tanh` at 1.22 rad so the field never turns back on
   itself.

**Colour** is keyed to horizontal position across the ramp
violet → azure → sea → lime → solar, with a small offset per input and a
small vertical drift, so the top of the field runs cooler and the bottom
runs warmer. Points are bucketed into 26 colour × 5 alpha buckets and painted
in batches, so one frame sets ~130 fill styles rather than 20,000.

**Controls.**

| Control | Drives |
| --- | --- |
| Clarity | Turbulence of the shared flow, and how hard each input bows before the waist. High clarity is laminar and orderly. |
| Proof | Dot spacing and weight. High proof is dense and emphatic. |
| Contact | Angular spread and how far the field reaches. High contact opens wide toward the headline. |

All three are real `<input type="range">` elements, wrapped in a
`role="group"` labelled by the hero's screen-reader heading, with visible
`<label>`s, `aria-describedby` explanations, 44px targets, and full keyboard
support.

**The track carries the metaphor.** The travelled part of each range is a
solid line in that input's seed colour; the part still to come is **stippled
in the same grain as the field it feeds**, so the control visibly hands off
to the drawing rather than stopping at a rule. Each dot is `--edge`, clearing
3:1 on its own, which is what satisfies 1.4.11 — a hairline at `--rule` sat at
1.25:1 and left the remaining range imperceptible. The stipple is the only
`repeating-linear-gradient` in the file and carries a file-scoped detector
waiver stating exactly that.
The canvas is `aria-hidden` and carries no essential text; a visible note
states that the drawing is decorative.

**Motion.** One slow phase drift, throttled to ~18fps (a 55ms budget) because
nothing moves fast enough to need more. The loop pauses when the hero leaves
the viewport and when the tab is hidden.

**Cost, and what it is allowed to cost.**

| | Before | After |
| --- | --- | --- |
| Canvas backing store (1440x900) | 30.6 MB | **17.9 MB** |
| Render per control tick (median) | 20.7 ms | **14.1 ms** |

Two changes, both visually free:

- **Resolution is per surface.** The hero animates and earns 1.75x. The two
  quiet bands are drawn once at low alpha, where 1.75x buys nothing the eye
  can find and costs ~13 MB. They render at 1x.
- **A surface nobody can see is not repainted.** Each surface tracks its own
  visibility through one `IntersectionObserver` with a 120px margin; an
  off-screen surface records that it owes a frame and pays it on the way in.

**Rejected: coarser integration while dragging.** Halving the step count and
scaling the step length looks like a free accuracy trade, and it is not: it
drew 27% fewer dots and moved the field's centroid 41px, so the picture would
visibly pop when the hand left the slider. Measured, rejected, removed. If a
future pass needs the hero cheaper, cut path count or dot density — both
degrade smoothly. Do not reach for integration resolution.

**Staleness.** `resize` and `ResizeObserver` are throttled in background tabs,
so a tab resized while hidden returns with a buffer sized for the old
viewport. `visibilitychange` re-measures on the way back in. Verified by
corrupting a canvas buffer and watching the handler restore it.

**Fonts.** `barlow-500` (the headline, which is also the LCP element) and
`barlow-400` (body) are preloaded; the other three are discovered from CSS.
Measured request starts: 10ms for the preloaded pair, 16–17ms for the rest.
CLS is 0.

**The motion is a breath, not a rotation.** The phase used to enter the curl
terms unbounded, so over its ~39s cycle the field travelled right through and
out of the composition it was approved from: the centroid swung 41px and the
upper plume disappeared entirely. Phase now drives three bounded oscillators
(0.40 / 0.28 / 0.22 rad), so the field moves around its resting frame and
never leaves it. Measured excursion after the change: 7px. Every load, and
every moment of the cycle, reads as the approved comp.

**Reduced motion.** `prefers-reduced-motion: reduce` renders the complete
field at phase 0 — the centre of the breath, not an arbitrary offset — and
never starts the loop, verified as exactly one `requestAnimationFrame` call
per control change and zero otherwise. The static state is the whole drawing.
The media query is observed live, so toggling the OS setting takes effect
without a reload.

The CSS side is deliberate rather than a blanket kill. There are no
`@keyframes` on this page and exactly three transitions, of which only the
skip link's slide is positional; that one is removed. Hover and focus colour
feedback is not motion and is kept, because removing it would cost real state
information. There are zero `!important` declarations in the file.

**Text safety.** Each surface fades out before the prose it sits behind, and
the fade boundary is **measured from the live DOM** (the outcome column's left
edge, the service prose's right edge, the closing column's right edge) rather
than guessed from a fraction. On phones the two quiet bands are hidden
entirely, because a phone has no free column to put them in.

---

## 6. Content and evidence rules

**Never on this page:** prices, delivery-time guarantees, "built in hours",
AI or production-speed claims, search-ranking promises, performance
statistics, client counts, testimonials, logos, invented company names,
"award-winning", "full-service agency".

**Evidence labelling is load-bearing.**

| Entry | Label | Truth |
| --- | --- | --- |
| My father's business site | Real project | A real site Connor designed and built for his father. Described as family work, not a commission. |
| Hawaii outreach concept, first | Concept study | Unsolicited demonstration sent to a business in Hawaii. No response. Never client work. |
| Hawaii outreach concept, second | Concept study | Same origin, same silence. |

Status is never carried by colour alone: every status pairs a distinct shape
glyph (circle / square / triangle) with the words "Real project" or "Concept
study", and the legend repeats the pairing.

The offer sequence is fixed: **Presence Check → Website Build → Owner
Handoff**, and the process mirrors it: **Review → Build → Handoff**.

Voice is candid, local, and first-person. No agency jargon. Manufactured
contrast ("Not X. Just Y.") appears at most once on the page.

---

## 7. Responsive behaviour

Two breakpoints: **720px** and **1120px**.

| Band | Composition |
| --- | --- |
| < 720px | Phone. One column, compact field band, controls stacked. |
| 720–1119px | Tablet. One column, but a deliberate one: the field band grows to `clamp(330px,40vw,470px)`, the three controls sit side by side, and the service rows, work index, and process take their multi-column form. The quiet field bands switch on here, because the prose columns finally leave a free margin. |
| ≥ 1120px | Desktop. The three-part controls / field / outcome topology. |

**The desktop breakpoint is 1120, not 960, and that is load-bearing.** The
hero grid is `minmax(230px,25%) 1fr minmax(430px,40%)`. Below about 1120 both
`minmax()` floors bind at once, consuming 75% of the row and leaving the field
roughly 200px — a fifth of the viewport, against a brief that asks for it to
own half the fold. Measured field room: 201px (21%) at 960 under the old
breakpoint; 325px (29%) at 1120, 489px (34%) at 1440, 569px (30%) at 1920
under the current one. The floors no longer bind anywhere the grid is active.
If the breakpoint is ever lowered, the floors have to come down with it.

The canvas mirrors the same three bands: the field's opening is damped to
`tiltK 0.62 / fanK 0.78` in a compact phone band, `0.84 / 0.94` in the taller
tablet band, and undamped on desktop. The JS thresholds (`>= 720`, `>= 1120`)
must stay in step with the CSS ones.

**Phone hero order is mandatory and must not be reordered:**

1. Headline and primary action
2. Transformation field
3. Clarity / Proof / Contact controls

This order holds on tablet too. Verified at 320, 390, 900, and 1119px.

DOM order is outcome → field → controls, so reading order, focus order, and
phone visual order all agree without `order` hacks fighting the markup. On
desktop the field is promoted to an absolute layer beneath the two text
columns.

The control hint sits **above** the three sliders, not below them. That is a
composition decision, not a copy decision: it drops the slider block toward
the vertical centre of the hero so the three lines leave the controls at the
height the approved comp puts them.

The header is `flex-wrap: wrap` with the contact pill on `margin-left:auto`.
At 390px and up it is one row; at 320px it wraps to two rather than
overflowing.

**Without JavaScript** a `<noscript><style>` block in the head hides the
field, the three controls, and the two quiet bands, and the hero collapses to
a single left-aligned column. The canvas cannot draw and the controls cannot
act, so showing an empty void or three dead sliders would be worse than
showing neither. Everything that sells the work — offer, evidence, process,
contact — is static markup and survives untouched.

**Do not rebuild this guard on a class set by script.** A guard that hides
content must not depend on a script surviving in order to un-hide it — strip
the script and the hero disappears in a browser where scripting works fine.
`<noscript>` reports the real condition and needs nothing to have run.

| State | Result |
| --- | --- |
| Scripting on | Field draws, controls live. |
| Script stripped, scripting on | Hero intact, controls present, canvas empty. |
| Scripting off | Clean single-column hero, no void. |

**Under `forced-colors: active`** the seed gradient and the field carry no
meaning once the OS repaints every surface, so all three canvases are hidden,
the primary action takes a real `ButtonText` border instead of relying on its
gradient, the range tracks go solid `CanvasText` at 2px, and focus rings
switch to `Highlight`. The status glyphs need no special handling: shape plus
word already carries the distinction that colour never did.

Verified:

- No horizontal overflow at 320, 390, 900, 1119, 1120, 1440, or 1920px, or at
  200% text zoom.
- Zero canvas alpha behind text on all three surfaces, re-measured per pixel at
  every one of those widths where the surface is visible.
- Readable at 200% text zoom (root 32px): no overflow, no clipping, no
  overlap. The headline is `rem`-capped so it scales with user text size
  instead of being pinned by a viewport override.
- Touch targets are ≥44px: wordmark 44, contact 44, sliders 44, actions 56.
  The only smaller target is the inline `mailto:` link inside a sentence,
  which duplicates the 56px action directly above it.
- Focus is visible everywhere: a 2px `--ink` outline at 3px offset on light,
  `#F5F4F9` on the dark section.
- Skip link to `#main` is the first focusable element, and its focus ring is
  `--ground` rather than the global `--ink`, which would have been a 1:1 ring
  against the link's own ink background.
- Non-text contrast: range track stipple 3.09:1, contact-pill border 3.09:1,
  control thumbs 5.32 / 3.59 / 3.26:1. All text re-verified after these
  changes: 44 elements checked, zero failures.

---

## 8. Unresolved production replacements

These are placeholders. Each is marked with a `SOURCE:` comment in
`index.html` at the point of use.

1. **`connor@husserweb.com`** — unverified production placeholder. Confirm the
   live mailbox before launch. Appears twice (action and inline link).
2. **No phone number is published.** Do not add one until it is confirmed.
3. **Father's project: URL and preferred public name** — the entry currently
   reads "Link and project name pending confirmation." Add the link only once
   confirmed.
4. **Hawaii concepts: business names and shareable URLs** — withheld pending
   permission. If permission is never granted, the ordinal titles stay.
5. **`husserweb.com` as a brand name** is not confirmed (see `PRODUCT.md`).
   The page leads with the personal name "Connor Husser" everywhere and never
   presents a company name, so a domain change costs one mailto string.
6. *(Resolved — `--ground-sunk` and `--rule-strong` were unused and have been
   deleted. All 24 remaining tokens are referenced.)*

---

## 9. Known, accepted deviations

- **Violet-to-yellow gradient.** An automated slop detector may flag a
  violet/azure gradient as an AI-palette tell. It is retained deliberately:
  it is the approved comp's seed ramp, it is confined to the field and the
  one primary action, and it is never used as gradient text.
- **A full-sentence headline at 72px.** Also potentially flagged. It is the
  approved exact headline at the approved scale, and it occupies roughly a
  third of the desktop first viewport, not all of it.
- **One file-scoped detector waiver**: `repeating-stripes-gradient`. The rule
  targets decorative surface stripes; the only repeating gradient here is a
  range track meeting a contrast requirement. The reason travels with the file
  at the rule itself.
- **Focus order places the primary action before the three controls**, which
  on desktop sit to its left. This is intentional: the action is the page's
  purpose and the controls are decorative, so priority order beats spatial
  order here.
