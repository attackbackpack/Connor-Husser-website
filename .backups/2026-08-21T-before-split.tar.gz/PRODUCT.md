# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

The primary audience is owners of local businesses, initially in and around Sioux Falls, who need a credible and useful online presence without managing a web project themselves. The practice is intentionally not limited to one industry.

## Product Purpose

Connor Husser's personal practice helps local businesses become easier to understand, trust, and contact online. Success means delivering a clear, mobile-friendly website and a clean ownership handoff through one accountable person.

## Positioning

The practice is personal rather than agency-shaped: Connor speaks with the owner, designs and builds the work, handles the launch, and remains directly reachable. AI-assisted production is an internal capability, not the customer-facing promise.

## Operating Context

Prospective clients may have an outdated website, only a social profile, or no useful online presence. Work begins with a short review of what already exists, moves to a fixed and understandable scope, and ends with launch and ownership handoff. Optional ongoing care may be offered only after its limits are defined.

## Capabilities and Constraints

- Current implementation is a static single-page website.
- Connor can produce website concepts and implementations quickly with AI assistance.
- The brand may serve any type of local business rather than specializing in one trade.
- Exact package prices, revision limits, delivery conditions, care-plan limits, phone number, and production email remain open decisions.
- Delivery speed must account for client response time, content, access, review, and scope; production speed alone is not a public guarantee.
- Search visibility, leads, revenue, and precise load-time results must not be guaranteed.

## Brand Commitments

- This is Connor Husser's overall personal brand, not a fictional multi-person agency.
- The voice should remain candid, direct, local, and free of agency jargon.
- The surname is useful trust equity; the existing name "Husser Web Co." is not confirmed and may be replaced.

## Evidence on Hand

- One real website made for Connor's father; it may be shown only with the relationship and outcome described accurately.
- Website demonstrations originally created as unsolicited outreach concepts for businesses in Hawaii; they may be shown only as concept work, not client work.
- No unrelated client sites, client testimonials, client-count claims, or proven commercial performance results are currently available.
- The current portrait, phone number, and some contact details in `index.html` are placeholders.

## Product Principles

1. Personal accountability is the brand's strongest proof.
2. Demonstrate real work and label concept work honestly.
3. Sell a clear business outcome and process, not AI usage or hours spent.
4. Keep offers understandable, bounded, and transferable to the client.
5. Earn broader claims through completed projects rather than implying an established agency history.

## Accessibility & Inclusion

The public website must remain usable with keyboard navigation, readable at phone widths and enlarged text, and clear without relying on color, motion, or industry knowledge.
